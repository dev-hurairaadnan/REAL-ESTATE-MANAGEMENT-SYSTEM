//
// Created by Dev.Huraira on 5/22/2025.
//

#ifndef CUSTOMER_DETAILS_VIEW_CLASS_H
#define CUSTOMER_DETAILS_VIEW_CLASS_H
#include "C:\Users\MMT\CLionProjects\REAL ESTATE MANAGEMENT SYSTEM STCTURED\MODEL\agent model\CUSTOMER_DETAILS.h"


class customer_details_view_class {
public:
 CUSTOMER_DETAILS getCustomerDetailsFromUser();
 CUSTOMER_DETAILS view_update_customer_input();
 string view_get_customer_name_for_deletion();
};



#endif //CUSTOMER_DETAILS_VIEW_CLASS_H
