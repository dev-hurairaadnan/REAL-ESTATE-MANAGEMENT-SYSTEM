#ifndef COMMISSION_CALCULATOR_CONTROLLER_H
#define COMMISSION_CALCULATOR_CONTROLLER_H
#include "C:/Users/MMT/CLionProjects/REAL ESTATE MANAGEMENT SYSTEM STCTURED/MODEL/agent model/CommissionCalculatorModel.h"
#include "C:/Users/MMT/CLionProjects/REAL ESTATE MANAGEMENT SYSTEM STCTURED/MODEL/agent model/CommissionCalculatorModel.h"
#include "C:/Users/MMT/CLionProjects/REAL ESTATE MANAGEMENT SYSTEM STCTURED/VIEW/AGENT VIEW/commishion view/CommissionCalculatorView.h"
#include "C:/Users/MMT/CLionProjects/REAL ESTATE MANAGEMENT SYSTEM STCTURED/DATA BASE/agent data base/commishion calculator data base/CommissionCalculatorDB.h"
#include <string>
#include <vector>



class CommissionCalculatorController {
public:
    void performCommissionCalculation();

    void displayCommissionHistory();
};

#endif
