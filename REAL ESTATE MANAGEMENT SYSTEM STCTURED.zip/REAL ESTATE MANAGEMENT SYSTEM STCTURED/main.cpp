
#include <iostream>
#include "C:\Users\MMT\CLionProjects\REAL ESTATE MANAGEMENT SYSTEM STCTURED\controoler\login\LoginController.h"

int main() {

LoginController obj;
obj.loginAndRedirect();


    }

